package BibliotecaRamon;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Pruebas {
    List<Autor> conjuntoAutores = new ArrayList<>();

    public Pruebas() {
        leerTexto();
        mostrarAutores();
    }

    private void leerTexto() {
        boolean nuevoAutor;

        try (Scanner leer = new Scanner(new File("Libros.txt"))) {
            while (leer.hasNextLine()) {
                String[] datos = leer.nextLine().split("[|]");
                Autor autor = new Autor(datos[1], Integer.parseInt(datos[2]));

/*
            if (!conjuntoAutores.contains(autor))
                conjuntoAutores.add(autor);
*/
                nuevoAutor = true;
                for (Autor a : conjuntoAutores)
                    if (a.getNombre().contains(autor.getNombre())){
                        nuevoAutor = false;
                        break;
                    }
                if (nuevoAutor)
                    conjuntoAutores.add(autor);
                //System.out.println();
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error al leer el archivo");
        }
    }

    private void mostrarAutores() {
        try(PrintWriter printer = new PrintWriter("autores.tmp")) {
            for (Autor autor : conjuntoAutores.stream().sorted().toList())
                printer.println(autor);
            System.out.println(conjuntoAutores.size());
        }
        catch (FileNotFoundException e) {
            System.err.println("Error al leer el archivo");
        }
    }
}
