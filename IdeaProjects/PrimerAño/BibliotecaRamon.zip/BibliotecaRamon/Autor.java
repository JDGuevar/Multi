package BibliotecaRamon;

public class Autor extends Persona{
    private String idAutor;

    public Autor(String nombre, int edad){
        super(nombre, edad);
        this.idAutor = obtenerId('A');
    }

    public Autor(String nombre){
        super(nombre,Persona.SIN_EDAD);
        setNombre(nombre);
    }

    public void generarAutores(){
        Autor[] autores = new Autor[25];
        for(Autor autor : autores){
            autor = new Autor("El Quijote", 300);
        }
    }

    public String getIdAutor() {
        return idAutor;
    }

    public void mostrar(){
        System.out.printf("Autor: %s - %s - %d%n", idAutor, getNombre(), getEdad());
    }

    @Override
    public String toString() {
        return String.format("Autor: %s - %s - %d%n", idAutor, getNombre(), getEdad());
    }

    public int compareTo(Autor otro){
        return this.getNombre().compareTo(otro.getNombre());
    }
}