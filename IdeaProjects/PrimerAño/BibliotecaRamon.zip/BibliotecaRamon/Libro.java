package BibliotecaRamon;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Libro {
    private String titulo;
    private List<String> autores = new ArrayList<String>();

    public Libro(String titulo) {
        this.titulo = titulo;
    }

    public Libro(String titulo, String ... autores){ /* "Argumentos variables", lo que permite que un método acepte un número variable de argumentos del mismo tipo. Como un array de objetos*/
        this.titulo = titulo;
        this.autores.addAll(Arrays.asList(autores));
    }

    public void addAutor(String autor){
      autores.add(autor);
    }

    public void mostrarAutores(){
        System.out.println(autores.toString());
        for (String autor : autores)
            System.out.println(autor);
    }
}
