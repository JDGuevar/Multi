import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Viewer extends JFrame implements ActionListener {

    JButton boton;
    Panel[] images;
    int galleryIndex = 0;

    public Viewer(){
        setTitle("Duraso");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // sale del programa cuando cierras de la ventana.
        setResizable(false); // hace que no puedas maximizar la ventana.
        images = new Panel[]{new Panel("images/1.jpeg"), new Panel("images/2.jpeg"), new Panel("images/3.jpeg")};
        add(images[0]);
        pack(); // hace que la ventana se adapte al panel, pero el contenido será el tamaño fijo.
        setLocationRelativeTo(null); // la ventana aparece en centrado de la pantalla.
        setVisible(true);
        boton = new JButton("Next");
        boton.setVisible(true);
        colocarBoton();
        boton.addActionListener(this);
        add(boton);
    }
    public static void main(String[] args) {
        new Viewer();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==boton) {
            remove(images[galleryIndex]);
            galleryIndex = (galleryIndex + 1) % images.length;
            add(images[galleryIndex]);
            pack();
            colocarBoton();
            setLocationRelativeTo(null);
        }
    }

    private void colocarBoton() {
        boton.setBounds((getWidth()/2) - 50,getHeight() - 100,100,30);
    }
}