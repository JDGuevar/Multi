import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Panel extends JPanel {
    private BufferedImage image;

    public Panel(String imageName) {
        try {
            image = ImageIO.read(new File(imageName));
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

            int panelwidth = image.getWidth();
            int panelheight = image.getHeight();
            double aspectRatio = (double) panelwidth / panelheight;

            if (panelheight > screenSize.height) {
                panelheight = 9 * screenSize.height/10;
                panelwidth = (int) (panelheight * aspectRatio);
            }
            if (panelwidth > screenSize.width) {
                panelwidth = 9 * screenSize.width/10;
                panelheight = (int) (panelwidth / aspectRatio);
            }

            setPreferredSize(new Dimension(panelwidth, panelheight));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
    }
}
