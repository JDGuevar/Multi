public class ClassName {
    public ClassName(){
        System.out.println("this has no parameter");
    }
    public ClassName(int arg){
        System.out.println("this has integer");
    }
    public ClassName(double arg){
        System.out.println("this has double");
    }
}
