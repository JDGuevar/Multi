public interface Algorithm
{
    void sorting(int[] array);
}
