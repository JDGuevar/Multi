public class Pruebas {
    public static void main(String[] args) {
        Diagonals d = new Diagonals(5,5);

    }
}
