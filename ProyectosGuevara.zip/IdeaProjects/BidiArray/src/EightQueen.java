public class EightQueen {
    private final int medida = 4;

}