public class Main {
    public static void main(String[] args) {
        Quadrat q = new Quadrat();
        q.omplirDirecte();
        q.mostrarDirecte();

        new Quadrat2(5);
        new Quadrat2(9);
    }
}