package ascii;

public class Main{
    public static void main(String[] args){
        new Triangle(1024,768, "wallpaper5", 6, 0.6);
    }
}