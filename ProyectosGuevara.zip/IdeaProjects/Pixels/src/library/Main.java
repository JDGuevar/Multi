package library;

public class Main {
    public static void main(String[] args) {
        new Poligono(1024,768, 0.6, 5);
    }
}
