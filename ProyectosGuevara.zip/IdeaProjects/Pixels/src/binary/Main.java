package binary;

public class Main {
    public static void main(String[] args) {
        new Poligono(1024, 768, "Andrea", 0.7, 5);
    }
}
