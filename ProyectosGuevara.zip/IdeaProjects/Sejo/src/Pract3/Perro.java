package Pract3;

public class Perro {
    public final void ladrar(){
        System.out.println("Guau guau");
    }
}
