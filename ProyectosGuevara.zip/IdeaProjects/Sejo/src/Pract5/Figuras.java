package Pract5;

public abstract class Figuras {

    private String color;
    abstract double area();
    abstract double perimeter();
}
