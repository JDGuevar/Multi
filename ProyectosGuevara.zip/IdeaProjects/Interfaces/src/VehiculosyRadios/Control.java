package VehiculosyRadios;

public interface Control {
    void encender();
    void apagar();
}
