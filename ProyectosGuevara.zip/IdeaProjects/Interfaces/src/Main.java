public class Main {
    public static void main(String[] args) {
        Partido p = new Partido();
        p.generarPartido();
        p.mostrarDatos();

    }
}
